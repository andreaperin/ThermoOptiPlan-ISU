<?xml version="1.0" encoding="utf-8"?>
<OpenGeoSysGLI>
  <name>TOP_BW</name>
  <points>
    <point id="0" x="0" y="0" z="-1025"/>
    <point id="1" x="3000" y="0" z="-1025"/>
    <point id="2" x="3000" y="1000" z="-1025"/>
    <point id="3" x="0" y="1000" z="-1025"/>
    <point id="4" x="0" y="0" z="-1144.9"/>
    <point id="5" x="992" y="0" z="-1144.9"/>
    <point id="6" x="1000" y="0" z="-1144.9"/>
    <point id="7" x="1008" y="0" z="-1144.9"/>
    <point id="8" x="1992" y="0" z="-1144.9"/>
    <point id="9" x="2000" y="0" z="-1144.9"/>
    <point id="10" x="2008" y="0" z="-1144.9"/>
    <point id="11" x="3000" y="0" z="-1144.9"/>
    <point id="12" x="3000" y="1000" z="-1144.9"/>
    <point id="13" x="0" y="1000" z="-1144.9"/>
    <point id="14" x="0" y="0" z="-1150.8"/>
    <point id="15" x="992" y="0" z="-1150.8"/>
    <point id="16" x="1000" y="0" z="-1150.8"/>
    <point id="17" x="1008" y="0" z="-1150.8"/>
    <point id="18" x="1992" y="0" z="-1150.8"/>
    <point id="19" x="2000" y="0" z="-1150.8"/>
    <point id="20" x="2008" y="0" z="-1150.8"/>
    <point id="21" x="3000" y="0" z="-1150.8"/>
    <point id="22" x="3000" y="1000" z="-1150.8"/>
    <point id="23" x="0" y="1000" z="-1150.8"/>
    <point id="24" x="0" y="0" z="-1239.9"/>
    <point id="25" x="992" y="0" z="-1239.9"/>
    <point id="26" x="1000" y="0" z="-1239.9"/>
    <point id="27" x="1008" y="0" z="-1239.9"/>
    <point id="28" x="1992" y="0" z="-1239.9"/>
    <point id="29" x="2000" y="0" z="-1239.9"/>
    <point id="30" x="2008" y="0" z="-1239.9"/>
    <point id="31" x="3000" y="0" z="-1239.9"/>
    <point id="32" x="3000" y="1000" z="-1239.9"/>
    <point id="33" x="0" y="1000" z="-1239.9"/>
    <point id="34" x="0" y="0" z="-1265.7"/>
    <point id="35" x="992" y="0" z="-1265.7"/>
    <point id="36" x="1000" y="0" z="-1265.7"/>
    <point id="37" x="1008" y="0" z="-1265.7"/>
    <point id="38" x="1992" y="0" z="-1265.7"/>
    <point id="39" x="2000" y="0" z="-1265.7"/>
    <point id="40" x="2008" y="0" z="-1265.7"/>
    <point id="41" x="3000" y="0" z="-1265.7"/>
    <point id="42" x="3000" y="1000" z="-1265.7"/>
    <point id="43" x="0" y="1000" z="-1265.7"/>
    <point id="44" x="0" y="0" z="-1308.8"/>
    <point id="45" x="992" y="0" z="-1308.8"/>
    <point id="46" x="1000" y="0" z="-1308.8"/>
    <point id="47" x="1008" y="0" z="-1308.8"/>
    <point id="48" x="1992" y="0" z="-1308.8"/>
    <point id="49" x="2000" y="0" z="-1308.8"/>
    <point id="50" x="2008" y="0" z="-1308.8"/>
    <point id="51" x="3000" y="0" z="-1308.8"/>
    <point id="52" x="3000" y="1000" z="-1308.8"/>
    <point id="53" x="0" y="1000" z="-1308.8"/>
    <point id="54" x="0" y="0" z="-1338.3"/>
    <point id="55" x="992" y="0" z="-1338.3"/>
    <point id="56" x="1000" y="0" z="-1338.3"/>
    <point id="57" x="1008" y="0" z="-1338.3"/>
    <point id="58" x="1992" y="0" z="-1338.3"/>
    <point id="59" x="2000" y="0" z="-1338.3"/>
    <point id="60" x="2008" y="0" z="-1338.3"/>
    <point id="61" x="3000" y="0" z="-1338.3"/>
    <point id="62" x="3000" y="1000" z="-1338.3"/>
    <point id="63" x="0" y="1000" z="-1338.3"/>
    <point id="64" x="0" y="0" z="-1364.3"/>
    <point id="65" x="992" y="0" z="-1364.3"/>
    <point id="66" x="1000" y="0" z="-1364.3"/>
    <point id="67" x="1008" y="0" z="-1364.3"/>
    <point id="68" x="1992" y="0" z="-1364.3"/>
    <point id="69" x="2000" y="0" z="-1364.3"/>
    <point id="70" x="2008" y="0" z="-1364.3"/>
    <point id="71" x="3000" y="0" z="-1364.3"/>
    <point id="72" x="3000" y="1000" z="-1364.3"/>
    <point id="73" x="0" y="1000" z="-1364.3"/>
    <point id="74" x="0" y="0" z="-1375.1"/>
    <point id="75" x="992" y="0" z="-1375.1"/>
    <point id="76" x="1000" y="0" z="-1375.1"/>
    <point id="77" x="1008" y="0" z="-1375.1"/>
    <point id="78" x="1992" y="0" z="-1375.1"/>
    <point id="79" x="2000" y="0" z="-1375.1"/>
    <point id="80" x="2008" y="0" z="-1375.1"/>
    <point id="81" x="3000" y="0" z="-1375.1"/>
    <point id="82" x="3000" y="1000" z="-1375.1"/>
    <point id="83" x="0" y="1000" z="-1375.1"/>
    <point id="84" x="0" y="0" z="-1575"/>
    <point id="85" x="3000" y="0" z="-1575"/>
    <point id="86" x="3000" y="1000" z="-1575"/>
    <point id="87" x="0" y="1000" z="-1575"/>
  </points>

  <polylines>
    <polyline id="1" name = "Ton1_top">
      <pnt>0</pnt>
      <pnt>1</pnt>
      <pnt>2</pnt>
      <pnt>3</pnt>
      <pnt>0</pnt>
    </polyline>
    <polyline id="2" name = "Ton1_front">
      <pnt>0</pnt>
      <pnt>1</pnt>
      <pnt>11</pnt>
      <pnt>10</pnt>
      <pnt>9</pnt>
      <pnt>8</pnt>
      <pnt>7</pnt>
      <pnt>6</pnt>
      <pnt>5</pnt>
      <pnt>4</pnt>
      <pnt>0</pnt>
    </polyline>
    <polyline id="3" name = "Ton1_right">
      <pnt>1</pnt>
      <pnt>2</pnt>
      <pnt>12</pnt>
      <pnt>11</pnt>
      <pnt>1</pnt>
    </polyline>
    <polyline id="4" name = "Ton1_back">
      <pnt>2</pnt>
      <pnt>3</pnt>
      <pnt>13</pnt>
      <pnt>12</pnt>
      <pnt>2</pnt>
    </polyline>
    <polyline id="5" name = "Ton1_left">
      <pnt>3</pnt>
      <pnt>0</pnt>
      <pnt>4</pnt>
      <pnt>13</pnt>
      <pnt>3</pnt>
    </polyline>
    <polyline id="6" name = "Sand1_front">
      <pnt>4</pnt>
      <pnt>5</pnt>
      <pnt>6</pnt>
      <pnt>7</pnt>
      <pnt>8</pnt>
      <pnt>9</pnt>
      <pnt>10</pnt>
      <pnt>11</pnt>
      <pnt>21</pnt>
      <pnt>20</pnt>
      <pnt>19</pnt>
      <pnt>18</pnt>
      <pnt>17</pnt>
      <pnt>16</pnt>
      <pnt>15</pnt>
      <pnt>14</pnt>
      <pnt>4</pnt>
    </polyline>
    <polyline id="7" name = "Sand1_right">
      <pnt>11</pnt>
      <pnt>12</pnt>
      <pnt>22</pnt>
      <pnt>21</pnt>
      <pnt>11</pnt>
    </polyline>
    <polyline id="8" name = "Sand1_back">
      <pnt>12</pnt>
      <pnt>13</pnt>
      <pnt>23</pnt>
      <pnt>22</pnt>
      <pnt>12</pnt>
    </polyline>
    <polyline id="9" name = "Sand1_left">
      <pnt>13</pnt>
      <pnt>4</pnt>
      <pnt>14</pnt>
      <pnt>23</pnt>
      <pnt>13</pnt>
    </polyline>
    <polyline id="10" name = "Sand1_bottom">
      <pnt>14</pnt>
      <pnt>15</pnt>
      <pnt>16</pnt>
      <pnt>17</pnt>
      <pnt>18</pnt>
      <pnt>19</pnt>
      <pnt>20</pnt>
      <pnt>21</pnt>
      <pnt>22</pnt>
      <pnt>23</pnt>
      <pnt>14</pnt>
    </polyline>
    <polyline id="11" name = "Ton2_front">
      <pnt>14</pnt>
      <pnt>15</pnt>
      <pnt>16</pnt>
      <pnt>17</pnt>
      <pnt>18</pnt>
      <pnt>19</pnt>
      <pnt>20</pnt>
      <pnt>21</pnt>
      <pnt>31</pnt>
      <pnt>30</pnt>
      <pnt>29</pnt>
      <pnt>28</pnt>
      <pnt>27</pnt>
      <pnt>26</pnt>
      <pnt>25</pnt>
      <pnt>24</pnt>
      <pnt>14</pnt>
    </polyline>
    <polyline id="12" name = "Ton2_right">
      <pnt>21</pnt>
      <pnt>22</pnt>
      <pnt>32</pnt>
      <pnt>31</pnt>
      <pnt>21</pnt>
    </polyline>
    <polyline id="13" name = "Ton2_back">
      <pnt>22</pnt>
      <pnt>32</pnt>
      <pnt>33</pnt>
      <pnt>23</pnt>
      <pnt>22</pnt>
    </polyline>
    <polyline id="14" name = "Ton2_left">
      <pnt>23</pnt>
      <pnt>14</pnt>
      <pnt>24</pnt>
      <pnt>33</pnt>
      <pnt>23</pnt>
    </polyline>
    <polyline id="15" name = "Sand2_top">
      <pnt>24</pnt>
      <pnt>25</pnt>
      <pnt>26</pnt>
      <pnt>27</pnt>
      <pnt>28</pnt>
      <pnt>29</pnt>
      <pnt>30</pnt>
      <pnt>31</pnt>
      <pnt>32</pnt>
      <pnt>33</pnt>
      <pnt>24</pnt>
    </polyline>
    <polyline id="16" name = "Sand2_front">
      <pnt>24</pnt>
      <pnt>25</pnt>
      <pnt>26</pnt>
      <pnt>27</pnt>
      <pnt>28</pnt>
      <pnt>29</pnt>
      <pnt>30</pnt>
      <pnt>31</pnt>
      <pnt>41</pnt>
      <pnt>40</pnt>
      <pnt>39</pnt>
      <pnt>38</pnt>
      <pnt>37</pnt>
      <pnt>36</pnt>
      <pnt>35</pnt>
      <pnt>34</pnt>
      <pnt>24</pnt>
    </polyline>
    <polyline id="17" name = "Sand2_right">
      <pnt>31</pnt>
      <pnt>32</pnt>
      <pnt>42</pnt>
      <pnt>41</pnt>
      <pnt>31</pnt>
    </polyline>
    <polyline id="18" name = "Sand2_back">
      <pnt>32</pnt>
      <pnt>33</pnt>
      <pnt>43</pnt>
      <pnt>42</pnt>
      <pnt>32</pnt>
    </polyline>
    <polyline id="19" name = "Sand2_left">
      <pnt>33</pnt>
      <pnt>24</pnt>
      <pnt>34</pnt>
      <pnt>43</pnt>
      <pnt>33</pnt>
    </polyline>
    <polyline id="20" name = "Sand2_bottom">
      <pnt>34</pnt>
      <pnt>35</pnt>
      <pnt>36</pnt>
      <pnt>37</pnt>
      <pnt>38</pnt>
      <pnt>39</pnt>
      <pnt>40</pnt>
      <pnt>41</pnt>
      <pnt>42</pnt>
      <pnt>43</pnt>
      <pnt>34</pnt>
    </polyline>
    <polyline id="21" name = "Ton3_front">
      <pnt>34</pnt>
      <pnt>35</pnt>
      <pnt>36</pnt>
      <pnt>37</pnt>
      <pnt>38</pnt>
      <pnt>39</pnt>
      <pnt>40</pnt>
      <pnt>41</pnt>
      <pnt>51</pnt>
      <pnt>50</pnt>
      <pnt>49</pnt>
      <pnt>48</pnt>
      <pnt>47</pnt>
      <pnt>46</pnt>
      <pnt>45</pnt>
      <pnt>44</pnt>
      <pnt>34</pnt>
    </polyline>
    <polyline id="22" name = "Ton3_right">
      <pnt>41</pnt>
      <pnt>42</pnt>
      <pnt>52</pnt>
      <pnt>51</pnt>
      <pnt>41</pnt>
    </polyline>
    <polyline id="23" name = "Ton3_back">
      <pnt>42</pnt>
      <pnt>43</pnt>
      <pnt>53</pnt>
      <pnt>52</pnt>
      <pnt>42</pnt>
    </polyline>
    <polyline id="24" name = "Ton3_left">
      <pnt>43</pnt>
      <pnt>34</pnt>
      <pnt>44</pnt>
      <pnt>53</pnt>
      <pnt>33</pnt>
    </polyline>
    <polyline id="25" name = "Sand3_top">
      <pnt>44</pnt>
      <pnt>45</pnt>
      <pnt>46</pnt>
      <pnt>47</pnt>
      <pnt>48</pnt>
      <pnt>49</pnt>
      <pnt>50</pnt>
      <pnt>51</pnt>
      <pnt>52</pnt>
      <pnt>53</pnt>
      <pnt>44</pnt>
    </polyline>
    <polyline id="26" name = "Sand3_front">
      <pnt>44</pnt>
      <pnt>45</pnt>
      <pnt>46</pnt>
      <pnt>47</pnt>
      <pnt>48</pnt>
      <pnt>49</pnt>
      <pnt>50</pnt>
      <pnt>51</pnt>
      <pnt>61</pnt>
      <pnt>60</pnt>
      <pnt>59</pnt>
      <pnt>58</pnt>
      <pnt>57</pnt>
      <pnt>56</pnt>
      <pnt>55</pnt>
      <pnt>54</pnt>
      <pnt>44</pnt>
    </polyline>
    <polyline id="27" name = "Sand3_right">
      <pnt>51</pnt>
      <pnt>52</pnt>
      <pnt>62</pnt>
      <pnt>61</pnt>
      <pnt>51</pnt>
    </polyline>
    <polyline id="28" name = "Sand3_back">
      <pnt>52</pnt>
      <pnt>53</pnt>
      <pnt>63</pnt>
      <pnt>62</pnt>
      <pnt>52</pnt>
    </polyline>
    <polyline id="29" name = "Sand3_left">
      <pnt>53</pnt>
      <pnt>44</pnt>
      <pnt>54</pnt>
      <pnt>63</pnt>
      <pnt>53</pnt>
    </polyline>
    <polyline id="30" name = "Sand3_bottom">
      <pnt>54</pnt>
      <pnt>55</pnt>
      <pnt>56</pnt>
      <pnt>57</pnt>
      <pnt>58</pnt>
      <pnt>59</pnt>
      <pnt>60</pnt>
      <pnt>61</pnt>
      <pnt>62</pnt>
      <pnt>63</pnt>
      <pnt>54</pnt>
    </polyline>
    <polyline id="31" name = "Ton4_front">
      <pnt>54</pnt>
      <pnt>55</pnt>
      <pnt>56</pnt>
      <pnt>57</pnt>
      <pnt>58</pnt>
      <pnt>59</pnt>
      <pnt>60</pnt>
      <pnt>61</pnt>
      <pnt>71</pnt>
      <pnt>70</pnt>
      <pnt>69</pnt>
      <pnt>68</pnt>
      <pnt>67</pnt>
      <pnt>66</pnt>
      <pnt>65</pnt>
      <pnt>64</pnt>
      <pnt>54</pnt>
    </polyline>
    <polyline id="32" name = "Ton4_right">
      <pnt>61</pnt>
      <pnt>62</pnt>
      <pnt>72</pnt>
      <pnt>71</pnt>
      <pnt>61</pnt>
    </polyline>
    <polyline id="33" name = "Ton4_back">
      <pnt>62</pnt>
      <pnt>63</pnt>
      <pnt>73</pnt>
      <pnt>72</pnt>
      <pnt>62</pnt>
    </polyline>
    <polyline id="34" name = "Ton4_left">
      <pnt>63</pnt>
      <pnt>54</pnt>
      <pnt>64</pnt>
      <pnt>73</pnt>
      <pnt>63</pnt>
    </polyline>
    <polyline id="35" name = "Sand4_top">
      <pnt>64</pnt>
      <pnt>65</pnt>
      <pnt>66</pnt>
      <pnt>67</pnt>
      <pnt>68</pnt>
      <pnt>69</pnt>
      <pnt>70</pnt>
      <pnt>71</pnt>
      <pnt>72</pnt>
      <pnt>73</pnt>
      <pnt>64</pnt>
    </polyline>
    <polyline id="36" name = "Sand4_front">
      <pnt>64</pnt>
      <pnt>65</pnt>
      <pnt>66</pnt>
      <pnt>67</pnt>
      <pnt>68</pnt>
      <pnt>69</pnt>
      <pnt>70</pnt>
      <pnt>71</pnt>
      <pnt>81</pnt>
      <pnt>80</pnt>
      <pnt>79</pnt>
      <pnt>78</pnt>
      <pnt>77</pnt>
      <pnt>76</pnt>
      <pnt>75</pnt>
      <pnt>74</pnt>
      <pnt>64</pnt>
    </polyline>
    <polyline id="37" name = "Sand4_right">
      <pnt>71</pnt>
      <pnt>72</pnt>
      <pnt>82</pnt>
      <pnt>81</pnt>
      <pnt>71</pnt>
    </polyline>
    <polyline id="38" name = "Sand4_back">
      <pnt>72</pnt>
      <pnt>73</pnt>
      <pnt>83</pnt>
      <pnt>82</pnt>
      <pnt>72</pnt>
    </polyline>
    <polyline id="39" name = "Sand4_left">
      <pnt>73</pnt>
      <pnt>64</pnt>
      <pnt>74</pnt>
      <pnt>83</pnt>
      <pnt>73</pnt>
    </polyline>
    <polyline id="40" name = "Sand4_bottom">
      <pnt>74</pnt>
      <pnt>75</pnt>
      <pnt>76</pnt>
      <pnt>77</pnt>
      <pnt>78</pnt>
      <pnt>79</pnt>
      <pnt>80</pnt>
      <pnt>81</pnt>
      <pnt>82</pnt>
      <pnt>83</pnt>
      <pnt>74</pnt>
    </polyline>
    <polyline id="41" name = "Ton5_front">
      <pnt>74</pnt>
      <pnt>75</pnt>
      <pnt>76</pnt>
      <pnt>77</pnt>
      <pnt>78</pnt>
      <pnt>79</pnt>
      <pnt>80</pnt>
      <pnt>81</pnt>
      <pnt>85</pnt>
      <pnt>84</pnt>
      <pnt>74</pnt>
    </polyline>
    <polyline id="42" name = "Ton5_right">
      <pnt>81</pnt>
      <pnt>82</pnt>
      <pnt>86</pnt>
      <pnt>85</pnt>
      <pnt>81</pnt>
    </polyline>
    <polyline id="43" name = "Ton5_back">
      <pnt>82</pnt>
      <pnt>83</pnt>
      <pnt>87</pnt>
      <pnt>86</pnt>
      <pnt>82</pnt>
    </polyline>
    <polyline id="44" name = "Ton5_left">
      <pnt>83</pnt>
      <pnt>74</pnt>
      <pnt>84</pnt>
      <pnt>87</pnt>
      <pnt>83</pnt>
    </polyline>
    <polyline id="45" name = "Ton5_bottom">
      <pnt>84</pnt>
      <pnt>85</pnt>
      <pnt>86</pnt>
      <pnt>87</pnt>
      <pnt>84</pnt>
    </polyline>
    <polyline id="46" name = "Sand1_top">
      <pnt>4</pnt>
      <pnt>5</pnt>
      <pnt>6</pnt>
      <pnt>7</pnt>
      <pnt>8</pnt>
      <pnt>9</pnt>
      <pnt>10</pnt>
      <pnt>11</pnt>
      <pnt>12</pnt>
      <pnt>13</pnt>
      <pnt>4</pnt>
    </polyline>
    <polyline id="47" name = "Inj1">
      <pnt>6</pnt>
      <pnt>16</pnt>
    </polyline>
    <polyline id="48" name = "Inj2">
      <pnt>26</pnt>
      <pnt>36</pnt>
    </polyline>
    <polyline id="49" name = "Inj3">
      <pnt>46</pnt>
      <pnt>56</pnt>
    </polyline>
    <polyline id="50" name = "Inj4">
      <pnt>66</pnt>
      <pnt>76</pnt>
    </polyline>
    <polyline id="51" name = "Pump1">
      <pnt>9</pnt>
      <pnt>19</pnt>
    </polyline>
    <polyline id="52" name = "Pump2">
      <pnt>29</pnt>
      <pnt>39</pnt>
    </polyline>
    <polyline id="53" name = "Pump3">
      <pnt>49</pnt>
      <pnt>59</pnt>
    </polyline>
    <polyline id="54" name = "Pump4">
      <pnt>69</pnt>
      <pnt>79</pnt>
    </polyline>
  </polylines>

	<surfaces>
		<surface id="1" name ="top">
			<element p1="0" p2="1" p3="2"  />
			<element p1="2" p2="3" p3="0"  />
		</surface>
		<surface id="2" name="bottom">
			<element p1="84" p2="85" p3="86" />
			<element p1="86" p2="87" p3="84" />
		</surface>
	</surfaces>

</OpenGeoSysGLI>
